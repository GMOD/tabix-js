# grape VCF

This uses some interesting VCF format that actually contains gene expression
